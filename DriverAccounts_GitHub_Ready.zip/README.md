# Driver Accounts Android project

## Build APK using GitHub

1. Upload the **contents** of this ZIP to the root of a new GitHub repository (the files `settings.gradle`, `build.gradle`, and the `app` folder must be at the repository root).
2. In GitHub, open the repository's **Actions** tab.
3. The workflow named **Build Android APK** starts after pushing to `main` or `master`. You can also start it manually with **Run workflow**.
4. When the workflow completes successfully, open that workflow run, scroll to **Artifacts**, and download `DriverAccounts-debug-apk`.
5. The downloaded artifact contains `app-debug.apk`. Transfer it to the Android phone and install it. Android may ask you to allow installation from that source.

## Build configuration

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (installed by the GitHub Actions workflow; a Gradle wrapper is not included)
- Java: 17
- Compile SDK / target SDK: 35
- Minimum Android version: Android 6.0 (API 23)

## Important

This package includes a GitHub Actions workflow for building a **debug APK**. It has passed archive and JavaScript syntax checks, but an actual Android APK build has not been run in this environment. The first GitHub Actions run is the real build test. If it fails, share the error log so the failing dependency or source can be corrected.

The app's existing HTML, Java, and accounting logic have been retained; this update adds build automation and project instructions rather than changing the app's accounting behavior.
